<?php

return [
    'entity1' => [
        'entity_type' => 'person',
		'cid' => '1',
    ],
    'entity2' => [
        'entity_type' => 'person',
		'cid' => '1',
    ],
    'entity3' => [
        'entity_type' => 'person',
		'cid' => '1',
    ],
    'entity4' => [
        'entity_type' => 'corporation',
		'cid' => '1',
    ],
];