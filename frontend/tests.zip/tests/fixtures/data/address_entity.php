<?php

return [
    'address_entity1' => [
        'email_id' => '1',
		'entity_id' => '1'
    ],
    'address_entity2' => [
        'email_id' => '2',
		'entity_id' => '2'
    ],
];