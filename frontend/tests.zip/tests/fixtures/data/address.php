<?php

return [
    'address1' => [
        'address_line' => '49 Umbridge Road',
		'state_id' => '1',
		'country_id' => '1',
		'code' => '',
		'cid' => '1'
    ],
    'address2' => [
        'address_line' => '50 Umbridge Road',
		'state_id' => '1',
		'country_id' => '1',
		'code' => '',
		'cid' => '1'
    ],
    'address3' => [
        'address_line' => '51 Umbridge Road',
		'state_id' => '1',
		'country_id' => '1',
		'code' => '',
		'cid' => '1'
    ],
    'address4' => [
        'address_line' => '52 Umbridge Road',
		'state_id' => '1',
		'country_id' => '1',
		'code' => '',
		'cid' => '1'
    ],
];