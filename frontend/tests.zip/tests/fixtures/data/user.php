<?php

return [
    'admin' => [
        'username' => 'admin',
        'password' => '$2y$13$C0AmXXsce9pIJEbsq67rJ.LG6.um9bVYOqMwOK4aUCeproz8v3JYu',
		'person_id' => '1',
		'basic_role' => '1',
		'salt' => '2X6zOUK7d',
		'authKey' => '',
		'last_login' => '2018-09-14 08:10:42',
		'last_updated' => '2017-10-06',
		'deleted' => '0',
		'cid' => '1',
    ],
    'guest' => [
        'username' => 'guest',
        'password' => '$2y$13$bALWS4jJCxPAJK3NuAQ7Q.ohjx5n5rWt0AIywhcpi7xSp31ovrQNe',
		'person_id' => '2',
		'basic_role' => '1',
		'salt' => 'GGX6zUK7d',
		'authKey' => '',
		'last_login' => '2018-09-14 08:10:42',
		'last_updated' => '2017-10-06',
		'deleted' => '0',
		'cid' => '1',
    ],
    'junior' => [
        'username' => 'junior',
        'password' => '$2y$13$bALWS4jJCxPAJK3NuAQ7Q.ohjx5n5rWt0AIywhcpi7xSp31ovrQNe',
		'person_id' => '3',
		'basic_role' => '2',
		'salt' => '23X6zOUK7h'
		'authKey' => '',
		'last_login' => '2018-09-14 08:10:42',
		'last_updated' => '2017-10-06',
		'deleted' => '0',
		'cid' => '1',
    ],
	
];