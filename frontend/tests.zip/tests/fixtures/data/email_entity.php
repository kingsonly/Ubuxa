<?php

return [
    'email_entity1' => [
        'email_id' => '1',
		'entity_id' => '1'
    ],
    'email_entity2' => [
        'email_id' => '2',
		'entity_id' => '2'
    ],
    'email_entity3' => [
        'email_id' => '3',
		'entity_id' => '3'
    ],
];