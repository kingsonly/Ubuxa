<?php

return [
    'admin_device1' => [
        'user_id' => 1,
        'device_id' => 1,
    ],
    'admin_device2' => [
        'user_id' => 1,
        'device_id' => 2,
    ],
    'admin_device3' => [
        'user_id' => 1,
        'device_id' => 3,
    ],
    'admin_device4' => [
        'user_id' => 1,
        'device_id' => 4,
    ],
    'admin_device5' => [
        'user_id' => 1,
        'device_id' => 5,
    ],
    'admin_device6' => [
        'user_id' => 1,
        'device_id' => 6,
    ],
    'admin_device7' => [
        'user_id' => 1,
        'device_id' => 8,
    ],
    'admin_device8' => [
        'user_id' => 1,
        'device_id' => 11,
    ],
    'guest_device1' => [
        'user_id' => 2,
        'device_id' => 2,
    ],
    'guest_device1' => [
        'user_id' => 2,
        'device_id' => 9,
    ],
    'guest_device1' => [
        'user_id' => 2,
        'device_id' => 10,
    ],
    'guest_device1' => [
        'user_id' => 2,
        'device_id' => 11,
    ],
    'junior_device1' => [
        'user_id' => 3,
        'device_id' => 11,
    ],
];