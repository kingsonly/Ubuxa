<?php

return [
    'firefox56_windows10' => [
		'id' => 1, //39
        'device_serial' => 'a:5:{s:7:"browser";a:2:{s:4:"name";s:7:"Firefox";s:7:"version";a:5:{s:5:"major";i:56;s:5:"minor";i:0;s:5:"patch";N;s:5:"alias";N;s:8:"complete";s:4:"56.0";}}s:15:"renderingEngine";a:2:{s:4:"name";s:5:"Gecko";s:7:"version";a:5:{s:5:"major";N;s:5:"minor";N;s:5:"patch";N;s:5:"alias";N;s:8:"complete";N;}}s:15:"operatingSystem";a:2:{s:4:"name";s:7:"Windows";s:7:"version";a:5:{s:5:"major";i:10;s:5:"minor";N;s:5:"patch";N;s:5:"alias";N;s:8:"complete";s:2:"10";}}s:6:"device";a:5:{s:5:"model";N;s:5:"bran',
        'authKey' => 'N6mh2bV6bw06kF-5FbEscHrfUHNdZ770y3aQk8i30Js2jAuHT2qfY3kp_Guln-LCoJOWcN',
		'status_id' => '',
		'last_used' => '0000-00-00 00:00:00',
		'valid_to' => '2037-06-30 00:00:00',
		'cid' => 1,
    ],
    'firefox56_mac10.12' => [
		'id' => 2, //40
        'device_serial' => 'a:5:{s:7:"browser";a:2:{s:4:"name";s:7:"Firefox";s:7:"version";a:5:{s:5:"major";i:56;s:5:"minor";i:0;s:5:"patch";N;s:5:"alias";N;s:8:"complete";s:4:"56.0";}}s:15:"renderingEngine";a:2:{s:4:"name";s:5:"Gecko";s:7:"version";a:5:{s:5:"major";N;s:5:"minor";N;s:5:"patch";N;s:5:"alias";N;s:8:"complete";N;}}s:15:"operatingSystem";a:2:{s:4:"name";s:3:"Mac";s:7:"version";a:5:{s:5:"major";i:10;s:5:"minor";i:12;s:5:"patch";N;s:5:"alias";N;s:8:"complete";s:5:"10.12";}}s:6:"device";a:5:{s:5:"model";N;s:5:"br',
        'authKey' => 'Ms1xUYG-z8r2XYZAeT5TUBKd1roy5qi2c52zlS6XE0C54_0PpwFYXqVrEftItW9M0fVEQI',
		'status_id' => '',
		'last_used' => '0000-00-00 00:00:00',
		'valid_to' => '2037-06-30 00:00:00',
		'cid' => 1,
    ],
    'chrome61_windows10' => [
		'id' => 3, //41
        'device_serial' => 'a:5:{s:7:"browser";a:2:{s:4:"name";s:6:"Chrome";s:7:"version";a:5:{s:5:"major";i:61;s:5:"minor";i:0;s:5:"patch";N;s:5:"alias";N;s:8:"complete";s:4:"61.0";}}s:15:"renderingEngine";a:2:{s:4:"name";s:5:"Blink";s:7:"version";a:5:{s:5:"major";N;s:5:"minor";N;s:5:"patch";N;s:5:"alias";N;s:8:"complete";N;}}s:15:"operatingSystem";a:2:{s:4:"name";s:7:"Windows";s:7:"version";a:5:{s:5:"major";i:10;s:5:"minor";N;s:5:"patch";N;s:5:"alias";N;s:8:"complete";s:2:"10";}}s:6:"device";a:5:{s:5:"model";N;s:5:"brand',
        'authKey' => 'xkg5is1XveJLyW4Iw4aeSdTE9nHbKUvWr1gi1yidKbZZQKWGqSGRg4bBY_QvTvTYt9Az2N',
		'status_id' => '',
		'last_used' => '0000-00-00 00:00:00',
		'valid_to' => '2037-06-30 00:00:00',
		'cid' => 1,
    ],
    'firefox56_windows10' => [
		'id' => 4, //42
        'device_serial' => 'a:5:{s:7:"browser";a:2:{s:4:"name";s:7:"Firefox";s:7:"version";a:5:{s:5:"major";i:56;s:5:"minor";i:0;s:5:"patch";N;s:5:"alias";N;s:8:"complete";s:4:"56.0";}}s:15:"renderingEngine";a:2:{s:4:"name";s:5:"Gecko";s:7:"version";a:5:{s:5:"major";N;s:5:"minor";N;s:5:"patch";N;s:5:"alias";N;s:8:"complete";N;}}s:15:"operatingSystem";a:2:{s:4:"name";s:7:"Windows";s:7:"version";a:5:{s:5:"major";i:10;s:5:"minor";N;s:5:"patch";N;s:5:"alias";N;s:8:"complete";s:2:"10";}}s:6:"device";a:5:{s:5:"model";N;s:5:"bran',
        'authKey' => 'xT3zokqmIR4PeLKncp1Ob39PlY-iiWA8XLNEAjqksbVhDkj75Yka4lnwzfEaJsXSSffDOM',
		'status_id' => '',
		'last_used' => '0000-00-00 00:00:00',
		'valid_to' => '2037-06-30 00:00:00',
		'cid' => 1,
    ],
    'firefox56_windows10' => [
		'id' => 5, //43
        'device_serial' => 'a:5:{s:7:"browser";a:2:{s:4:"name";s:7:"Firefox";s:7:"version";a:5:{s:5:"major";i:56;s:5:"minor";i:0;s:5:"patch";N;s:5:"alias";N;s:8:"complete";s:4:"56.0";}}s:15:"renderingEngine";a:2:{s:4:"name";s:5:"Gecko";s:7:"version";a:5:{s:5:"major";N;s:5:"minor";N;s:5:"patch";N;s:5:"alias";N;s:8:"complete";N;}}s:15:"operatingSystem";a:2:{s:4:"name";s:7:"Windows";s:7:"version";a:5:{s:5:"major";i:10;s:5:"minor";N;s:5:"patch";N;s:5:"alias";N;s:8:"complete";s:2:"10";}}s:6:"device";a:5:{s:5:"model";N;s:5:"bran',
        'authKey' => 'v7VJaV4Y0hxLWRy94grldt213hhxMfUar6viinA9A_sN2HY5PhUtYiOMe9exyCwnzZSfI_',
		'status_id' => '',
		'last_used' => '0000-00-00 00:00:00',
		'valid_to' => '2037-06-30 00:00:00',
		'cid' => 1,
    ],
    'firefox56_windows10' => [
		'id' => 6, //44
        'device_serial' => 'a:5:{s:7:"browser";a:2:{s:4:"name";s:7:"Firefox";s:7:"version";a:5:{s:5:"major";i:56;s:5:"minor";i:0;s:5:"patch";N;s:5:"alias";N;s:8:"complete";s:4:"56.0";}}s:15:"renderingEngine";a:2:{s:4:"name";s:5:"Gecko";s:7:"version";a:5:{s:5:"major";N;s:5:"minor";N;s:5:"patch";N;s:5:"alias";N;s:8:"complete";N;}}s:15:"operatingSystem";a:2:{s:4:"name";s:7:"Windows";s:7:"version";a:5:{s:5:"major";i:10;s:5:"minor";N;s:5:"patch";N;s:5:"alias";N;s:8:"complete";s:2:"10";}}s:6:"device";a:5:{s:5:"model";N;s:5:"bran',
		'authKey' => 'Jgqz5uiLAPhTDou7SltXCyxFegdQEb1Jg8xEJnmd7rbaBF_0IVPHYVmo2xPlvqQqjvzSV0',
		'status_id' => '',
		'last_used' => '0000-00-00 00:00:00',
		'valid_to' => '2037-06-30 00:00:00',
		'cid' => 1,
    ],
    'chrome61_windows8.1' => [
		'id' => 7, //45
        'device_serial' => 'a:5:{s:7:"browser";a:2:{s:4:"name";s:6:"Chrome";s:7:"version";a:5:{s:5:"major";i:61;s:5:"minor";i:0;s:5:"patch";N;s:5:"alias";N;s:8:"complete";s:4:"61.0";}}s:15:"renderingEngine";a:2:{s:4:"name";s:5:"Blink";s:7:"version";a:5:{s:5:"major";N;s:5:"minor";N;s:5:"patch";N;s:5:"alias";N;s:8:"complete";N;}}s:15:"operatingSystem";a:2:{s:4:"name";s:7:"Windows";s:7:"version";a:5:{s:5:"major";i:8;s:5:"minor";i:1;s:5:"patch";N;s:5:"alias";N;s:8:"complete";s:3:"8.1";}}s:6:"device";a:5:{s:5:"model";N;s:5:"bra',
		'authKey' => 'oWPC7wyUDC2eZf1FxyQnZ5IzpN_bOrsJyVT0jGsyeu_SoOf1hXVKUvff_l0LK6XZ5ThGj2',
		'status_id' => '',
		'last_used' => '0000-00-00 00:00:00',
		'valid_to' => '2037-06-30 00:00:00',
		'cid' => 1,
    ],
    'firefox56_windows10' => [
		'id' => 8, //46
        'device_serial' => 'a:5:{s:7:"browser";a:2:{s:4:"name";s:7:"Firefox";s:7:"version";a:5:{s:5:"major";i:56;s:5:"minor";i:0;s:5:"patch";N;s:5:"alias";N;s:8:"complete";s:4:"56.0";}}s:15:"renderingEngine";a:2:{s:4:"name";s:5:"Gecko";s:7:"version";a:5:{s:5:"major";N;s:5:"minor";N;s:5:"patch";N;s:5:"alias";N;s:8:"complete";N;}}s:15:"operatingSystem";a:2:{s:4:"name";s:7:"Windows";s:7:"version";a:5:{s:5:"major";i:10;s:5:"minor";N;s:5:"patch";N;s:5:"alias";N;s:8:"complete";s:2:"10";}}s:6:"device";a:5:{s:5:"model";N;s:5:"bran',
		'authKey' => 'Vtt9aVpZGcN1YdZ5OtQpOwGrO27tU5w38Su6VyopKlaXbwh5eVqLkBIhuQOZElKDzMekjQ',
		'status_id' => '',
		'last_used' => '0000-00-00 00:00:00',
		'valid_to' => '2037-06-30 00:00:00',
		'cid' => 1,
    ],
    'firefox59_mac10.12' => [
		'id' => 9, //47
        'device_serial' => 'a:5:{s:7:"browser";a:2:{s:4:"name";s:7:"Firefox";s:7:"version";a:5:{s:5:"major";i:59;s:5:"minor";i:0;s:5:"patch";N;s:5:"alias";N;s:8:"complete";s:4:"59.0";}}s:15:"renderingEngine";a:2:{s:4:"name";s:5:"Gecko";s:7:"version";a:5:{s:5:"major";N;s:5:"minor";N;s:5:"patch";N;s:5:"alias";N;s:8:"complete";N;}}s:15:"operatingSystem";a:2:{s:4:"name";s:3:"Mac";s:7:"version";a:5:{s:5:"major";i:10;s:5:"minor";i:12;s:5:"patch";N;s:5:"alias";N;s:8:"complete";s:5:"10.12";}}s:6:"device";a:5:{s:5:"model";N;s:5:"br',
		'authKey' => 'Lnd6KPTpDjUUynAoFSTyWff0Bh4dhNp2DDfT_5bpP7pdGl9-3mhn7it-ljV7QsXkLvGwye',
		'status_id' => '',
		'last_used' => '0000-00-00 00:00:00',
		'valid_to' => '2037-06-30 00:00:00',
		'cid' => 1,
    ],
    'firefox59_mac10.12' => [
		'id' => 10, //48
        'device_serial' => 'a:5:{s:7:"browser";a:2:{s:4:"name";s:7:"Firefox";s:7:"version";a:5:{s:5:"major";i:59;s:5:"minor";i:0;s:5:"patch";N;s:5:"alias";N;s:8:"complete";s:4:"59.0";}}s:15:"renderingEngine";a:2:{s:4:"name";s:5:"Gecko";s:7:"version";a:5:{s:5:"major";N;s:5:"minor";N;s:5:"patch";N;s:5:"alias";N;s:8:"complete";N;}}s:15:"operatingSystem";a:2:{s:4:"name";s:3:"Mac";s:7:"version";a:5:{s:5:"major";i:10;s:5:"minor";i:12;s:5:"patch";N;s:5:"alias";N;s:8:"complete";s:5:"10.12";}}s:6:"device";a:5:{s:5:"model";N;s:5:"br',
		'authKey' => 'iJlMosIHxdxKPD5AKk6has9ySkFktReJK6EeY_BNBK8nzuVdpe09xvTmaMkVTn5oExe8K1',
		'status_id' => '',
		'last_used' => '0000-00-00 00:00:00',
		'valid_to' => '2037-06-30 00:00:00',
		'cid' => 1,
    ],
    'firefox61_windows10' => [
		'id' => 11, //49
        'device_serial' => 'a:5:{s:7:"browser";a:2:{s:4:"name";s:7:"Firefox";s:7:"version";a:5:{s:5:"major";i:61;s:5:"minor";i:0;s:5:"patch";N;s:5:"alias";N;s:8:"complete";s:4:"61.0";}}s:15:"renderingEngine";a:2:{s:4:"name";s:5:"Gecko";s:7:"version";a:5:{s:5:"major";N;s:5:"minor";N;s:5:"patch";N;s:5:"alias";N;s:8:"complete";N;}}s:15:"operatingSystem";a:2:{s:4:"name";s:7:"Windows";s:7:"version";a:5:{s:5:"major";i:10;s:5:"minor";N;s:5:"patch";N;s:5:"alias";N;s:8:"complete";s:2:"10";}}s:6:"device";a:5:{s:5:"model";N;s:5:"bran',
		'authKey' => '5_fp2gn7f-BO3sHTDdy6nnjiae7zX2l9Z7Z7Y8wgdRS-jEZ_4aDnhQKlCY74eLTLHouJEg',
		'status_id' => '',
		'last_used' => '0000-00-00 00:00:00',
		'valid_to' => '2037-06-30 00:00:00',
		'cid' => 1,
    ],
];