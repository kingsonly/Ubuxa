<?php

return [
    'email1' => [
        'address' => 'a.a.okechukwu@gmail.com',
		'cid' => '1'
    ],
    'email2' => [
        'address' => 'a.okechukwu@tycol.net',
		'cid' => '1'
    ],
    'email3' => [
        'address' => 'k.achumie@epsolu n.com',
		'cid' => '1'
    ],
    'email4' => [
        'address' => 'kokoshags@yahoo.co.uk',
		'cid' => '1'
    ],
];