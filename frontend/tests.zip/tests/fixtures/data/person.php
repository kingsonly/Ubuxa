<?php

return [
    'anthony' => [
        'first_name' => 'Anthony',
        'surname' => 'Okechukwu',
		'dob' => '2017-06-05 00:00:00',
		'entity_id' => '1',
		'create_date' => '2017-06-05 00:00:00',
		'cid' => '1',
    ],
    'kingsley' => [
        'first_name' => 'Kingsley',
        'surname' => 'Achumie',
		'dob' => '1995-06-05 00:00:00',
		'entity_id' => '2',
		'create_date' => '2017-06-05 00:00:00',
		'cid' => '1',
    ],
    'nnamdi' => [
        'first_name' => 'Nnamdi',
        'surname' => 'Ogungu',
		'dob' => '1980-03-05 00:00:00',
		'entity_id' => '3',
		'create_date' => '2017-06-05 00:00:00',
		'cid' => '1',
    ],
];