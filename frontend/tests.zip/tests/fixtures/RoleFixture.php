<?php
namespace frontend\tests\fixtures;

use yii\test\ActiveFixture;

class RoleFixture extends ActiveFixture
{
    public $modelClass = 'frontend\models\Role';
}