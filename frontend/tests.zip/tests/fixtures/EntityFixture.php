<?php
namespace frontend\tests\fixtures;

use yii\test\ActiveFixture;

class EntityFixture extends ActiveFixture
{
    public $modelClass = 'frontend\models\Entity';
}