<?php
namespace frontend\tests\fixtures;

use yii\test\ActiveFixture;

class AddressFixture extends ActiveFixture
{
    public $modelClass = 'frontend\models\Address';
}