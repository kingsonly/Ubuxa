<?php
namespace frontend\tests\fixtures;

use yii\test\ActiveFixture;

class EmailFixture extends ActiveFixture
{
    public $modelClass = 'frontend\models\Email';
}