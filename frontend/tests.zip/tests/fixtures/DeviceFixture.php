<?php
namespace frontend\tests\fixtures;

use yii\test\ActiveFixture;

class DeviceFixture extends ActiveFixture
{
    public $modelClass = 'frontend\models\Device';
}